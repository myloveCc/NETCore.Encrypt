using System;
using System.Collections.Generic;
using System.Text;

namespace NETCore.Encrypt
{
    public enum RsaSize
    {
        R2048=2048,
        R3072=3072,
        R4096=4096
    }
}
