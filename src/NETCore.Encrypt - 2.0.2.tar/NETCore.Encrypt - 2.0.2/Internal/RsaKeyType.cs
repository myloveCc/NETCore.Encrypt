using System;
using System.Collections.Generic;
using System.Text;

namespace NETCore.Encrypt.Internal
{
    public enum RsaKeyType
    {
        XML,
        JSON
    }
}
